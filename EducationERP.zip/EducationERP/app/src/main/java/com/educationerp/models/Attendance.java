package com.educationerp.models;

import java.util.Date;

public class Attendance {
    private String studentId;
    private String date;
    private boolean present;
    private String remarks;

    public Attendance() {
        // Empty constructor required for Firebase
    }

    public Attendance(String studentId, String date, boolean present, String remarks) {
        this.studentId = studentId;
        this.date = date;
        this.present = present;
        this.remarks = remarks;
    }

    // Getters and Setters
    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public boolean isPresent() { return present; }
    public void setPresent(boolean present) { this.present = present; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
}
