package com.educationerp.models;

public class PaymentReminder {
    private String id;
    private String studentId;
    private String semester;
    private String dueDate;
    private double dueAmount;
    private String reminderType; // First, Second, Final
    private String status; // Pending, Sent, Acknowledged
    private String message;
    private String createdDate;
    private String sentDate;

    public PaymentReminder() {
        // Empty constructor required for Firebase
    }

    public PaymentReminder(String id, String studentId, String semester,
                          String dueDate, double dueAmount, String reminderType,
                          String status, String message, String createdDate,
                          String sentDate) {
        this.id = id;
        this.studentId = studentId;
        this.semester = semester;
        this.dueDate = dueDate;
        this.dueAmount = dueAmount;
        this.reminderType = reminderType;
        this.status = status;
        this.message = message;
        this.createdDate = createdDate;
        this.sentDate = sentDate;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getDueDate() { return dueDate; }
    public void setDueDate(String dueDate) { this.dueDate = dueDate; }

    public double getDueAmount() { return dueAmount; }
    public void setDueAmount(double dueAmount) { this.dueAmount = dueAmount; }

    public String getReminderType() { return reminderType; }
    public void setReminderType(String reminderType) { 
        this.reminderType = reminderType; 
    }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getCreatedDate() { return createdDate; }
    public void setCreatedDate(String createdDate) { 
        this.createdDate = createdDate; 
    }

    public String getSentDate() { return sentDate; }
    public void setSentDate(String sentDate) { this.sentDate = sentDate; }

    public String generateReminderMessage() {
        return String.format(
            "Dear Student,\n\n" +
            "This is a %s reminder regarding your pending fee payment.\n" +
            "Semester: %s\n" +
            "Due Amount: ₹%.2f\n" +
            "Due Date: %s\n\n" +
            "Please clear your dues before the due date to avoid any late fees.\n\n" +
            "Best regards,\nEducation ERP Team",
            reminderType, semester, dueAmount, dueDate
        );
    }
}
