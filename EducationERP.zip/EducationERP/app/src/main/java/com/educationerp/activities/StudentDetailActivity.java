package com.educationerp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.educationerp.R;
import com.educationerp.models.Student;
import com.educationerp.utils.GoogleSheetsHelper;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import java.util.List;

public class StudentDetailActivity extends AppCompatActivity {
    private ImageView ivStudentPhoto;
    private TextView tvName, tvId, tvCourse, tvDepartment, tvBatch, tvGender, tvMobile, tvBook;
    private MaterialButton btnManageFees;
    private GoogleSheetsHelper sheetsHelper;
    private String studentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_detail);

        studentId = getIntent().getStringExtra("student_id");
        if (studentId == null) {
            finish();
            return;
        }

        initializeViews();
        setupToolbar();
        loadStudentDetails(studentId);
    }

    private void initializeViews() {
        ivStudentPhoto = findViewById(R.id.ivStudentPhoto);
        tvName = findViewById(R.id.tvName);
        tvId = findViewById(R.id.tvId);
        tvCourse = findViewById(R.id.tvCourse);
        tvDepartment = findViewById(R.id.tvDepartment);
        tvBatch = findViewById(R.id.tvBatch);
        tvGender = findViewById(R.id.tvGender);
        tvMobile = findViewById(R.id.tvMobile);
        tvBook = findViewById(R.id.tvBook);
        btnManageFees = findViewById(R.id.btnManageFees);
        
        sheetsHelper = new GoogleSheetsHelper(this, "credentials.json");

        btnManageFees.setOnClickListener(v -> {
            Intent intent = new Intent(this, FeeManagementActivity.class);
            intent.putExtra("student_id", studentId);
            startActivity(intent);
        });
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Student Details");
    }

    private void loadStudentDetails(String studentId) {
        sheetsHelper.getStudents(new GoogleSheetsHelper.SheetsCallback() {
            @Override
            public void onResult(List<List<Object>> values) {
                if (values != null) {
                    for (List<Object> row : values) {
                        if (row.size() >= 9 && row.get(0).toString().equals(studentId)) {
                            Student student = new Student(
                                row.get(0).toString(),  // id
                                row.get(1).toString(),  // name
                                row.get(2).toString(),  // course
                                row.get(3).toString(),  // department
                                row.get(4).toString(),  // batch
                                row.get(5).toString(),  // gender
                                row.get(6).toString(),  // mobile
                                row.get(7).toString(),  // book
                                row.get(8).toString()   // photoUrl
                            );
                            runOnUiThread(() -> displayStudentDetails(student));
                            break;
                        }
                    }
                }
            }

            @Override
            public void onError(Exception e) {
                // Handle error
            }
        });
    }

    private void displayStudentDetails(Student student) {
        tvName.setText(student.getName());
        tvId.setText(student.getId());
        tvCourse.setText(student.getCourse());
        tvDepartment.setText(student.getDepartment());
        tvBatch.setText(student.getBatch());
        tvGender.setText(student.getGender());
        tvMobile.setText(student.getMobile());
        tvBook.setText(student.getBook());

        if (!student.getPhotoUrl().isEmpty()) {
            Glide.with(this)
                .load(student.getPhotoUrl())
                .placeholder(R.drawable.ic_photo_placeholder)
                .error(R.drawable.ic_photo_placeholder)
                .into(ivStudentPhoto);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
