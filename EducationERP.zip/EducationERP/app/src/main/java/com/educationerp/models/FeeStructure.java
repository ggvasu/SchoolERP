package com.educationerp.models;

public class FeeStructure {
    private String courseId;
    private double tutionFee;
    private double examFee;
    private double otherFee;
    private double busFee;
    private String semester;

    public FeeStructure() {
        // Empty constructor required for Firebase
    }

    public FeeStructure(String courseId, double tutionFee, double examFee, 
                       double otherFee, double busFee, String semester) {
        this.courseId = courseId;
        this.tutionFee = tutionFee;
        this.examFee = examFee;
        this.otherFee = otherFee;
        this.busFee = busFee;
        this.semester = semester;
    }

    // Getters and Setters
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }

    public double getTutionFee() { return tutionFee; }
    public void setTutionFee(double tutionFee) { this.tutionFee = tutionFee; }

    public double getExamFee() { return examFee; }
    public void setExamFee(double examFee) { this.examFee = examFee; }

    public double getOtherFee() { return otherFee; }
    public void setOtherFee(double otherFee) { this.otherFee = otherFee; }

    public double getBusFee() { return busFee; }
    public void setBusFee(double busFee) { this.busFee = busFee; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public double getTotalFee() {
        return tutionFee + examFee + otherFee + busFee;
    }
}
