package com.educationerp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.educationerp.R;
import com.educationerp.adapters.StudentAdapter;
import com.educationerp.models.Student;
import com.educationerp.utils.GoogleSheetsHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class StudentListActivity extends AppCompatActivity implements StudentAdapter.OnStudentClickListener {
    private RecyclerView recyclerView;
    private StudentAdapter adapter;
    private SwipeRefreshLayout swipeRefresh;
    private GoogleSheetsHelper sheetsHelper;
    private List<Student> studentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_list);

        initializeViews();
        setupRecyclerView();
        loadStudents();

        FloatingActionButton fab = findViewById(R.id.fabAddStudent);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(this, StudentManagementActivity.class);
            startActivity(intent);
        });
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerView);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        swipeRefresh.setOnRefreshListener(this::loadStudents);
        sheetsHelper = new GoogleSheetsHelper(this, "credentials.json");
        studentList = new ArrayList<>();
    }

    private void setupRecyclerView() {
        adapter = new StudentAdapter(this, studentList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void loadStudents() {
        swipeRefresh.setRefreshing(true);
        sheetsHelper.getStudents(new GoogleSheetsHelper.SheetsCallback() {
            @Override
            public void onResult(List<List<Object>> values) {
                studentList.clear();
                if (values != null) {
                    for (List<Object> row : values) {
                        if (row.size() >= 9) {
                            Student student = new Student(
                                row.get(0).toString(),  // id
                                row.get(1).toString(),  // name
                                row.get(2).toString(),  // course
                                row.get(3).toString(),  // department
                                row.get(4).toString(),  // batch
                                row.get(5).toString(),  // gender
                                row.get(6).toString(),  // mobile
                                row.get(7).toString(),  // book
                                row.get(8).toString()   // photoUrl
                            );
                            studentList.add(student);
                        }
                    }
                }
                runOnUiThread(() -> {
                    adapter.notifyDataSetChanged();
                    swipeRefresh.setRefreshing(false);
                });
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(() -> swipeRefresh.setRefreshing(false));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_student_list, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterStudents(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterStudents(newText);
                return true;
            }
        });
        return true;
    }

    private void filterStudents(String query) {
        List<Student> filteredList = new ArrayList<>();
        for (Student student : studentList) {
            if (student.getName().toLowerCase().contains(query.toLowerCase()) ||
                student.getId().toLowerCase().contains(query.toLowerCase()) ||
                student.getCourse().toLowerCase().contains(query.toLowerCase()) ||
                student.getDepartment().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(student);
            }
        }
        adapter.updateList(filteredList);
    }

    @Override
    public void onStudentClick(Student student) {
        Intent intent = new Intent(this, StudentDetailActivity.class);
        intent.putExtra("student_id", student.getId());
        startActivity(intent);
    }
}
