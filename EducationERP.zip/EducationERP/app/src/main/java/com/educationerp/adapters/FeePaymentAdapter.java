package com.educationerp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.educationerp.R;
import com.educationerp.models.FeePayment;
import java.util.List;
import java.util.Locale;

public class FeePaymentAdapter extends RecyclerView.Adapter<FeePaymentAdapter.FeePaymentViewHolder> {
    private Context context;
    private List<FeePayment> feePayments;

    public FeePaymentAdapter(Context context, List<FeePayment> feePayments) {
        this.context = context;
        this.feePayments = feePayments;
    }

    @NonNull
    @Override
    public FeePaymentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_fee_payment, parent, false);
        return new FeePaymentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FeePaymentViewHolder holder, int position) {
        FeePayment payment = feePayments.get(position);
        holder.bind(payment);
    }

    @Override
    public int getItemCount() {
        return feePayments.size();
    }

    class FeePaymentViewHolder extends RecyclerView.ViewHolder {
        private TextView tvFeeType;
        private TextView tvAmount;
        private TextView tvDate;
        private TextView tvStatus;
        private TextView tvTransactionId;

        FeePaymentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvFeeType = itemView.findViewById(R.id.tvFeeType);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvTransactionId = itemView.findViewById(R.id.tvTransactionId);
        }

        void bind(FeePayment payment) {
            tvFeeType.setText(payment.getFeeType());
            tvAmount.setText(String.format(Locale.getDefault(), "₹%.2f", payment.getAmount()));
            tvDate.setText(payment.getPaymentDate());
            tvTransactionId.setText(payment.getTransactionId());
            
            tvStatus.setText(payment.getStatus());
            int colorRes = payment.getStatus().equals("Success") 
                ? R.color.success_green 
                : R.color.error_red;
            tvStatus.setTextColor(ContextCompat.getColor(context, colorRes));
        }
    }
}
