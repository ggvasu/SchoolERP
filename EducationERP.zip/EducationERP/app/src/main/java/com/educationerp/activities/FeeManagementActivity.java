package com.educationerp.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.educationerp.R;
import com.educationerp.adapters.FeePaymentAdapter;
import com.educationerp.models.FeePayment;
import com.educationerp.models.FeeStructure;
import com.educationerp.models.Student;
import com.educationerp.utils.GoogleSheetsHelper;
import com.google.android.material.button.MaterialButton;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FeeManagementActivity extends AppCompatActivity {
    private TextView tvTotalFee, tvPaidFee, tvDueFee;
    private Spinner spinnerSemester, spinnerFeeType;
    private MaterialButton btnPayFee;
    private RecyclerView rvFeeHistory;
    private FeePaymentAdapter adapter;
    private GoogleSheetsHelper sheetsHelper;
    private Student student;
    private FeeStructure feeStructure;
    private List<FeePayment> feePayments;
    private static final List<String> SEMESTERS = Arrays.asList("Sem 1", "Sem 2", "Sem 3", "Sem 4");
    private static final List<String> FEE_TYPES = Arrays.asList(
        "Tution Fee", "Exam Fee", "Other Fee", "Bus Fee"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fee_management);

        String studentId = getIntent().getStringExtra("student_id");
        if (studentId == null) {
            finish();
            return;
        }

        initializeViews();
        setupSpinners();
        loadStudentData(studentId);
    }

    private void initializeViews() {
        tvTotalFee = findViewById(R.id.tvTotalFee);
        tvPaidFee = findViewById(R.id.tvPaidFee);
        tvDueFee = findViewById(R.id.tvDueFee);
        spinnerSemester = findViewById(R.id.spinnerSemester);
        spinnerFeeType = findViewById(R.id.spinnerFeeType);
        btnPayFee = findViewById(R.id.btnPayFee);
        rvFeeHistory = findViewById(R.id.rvFeeHistory);

        sheetsHelper = new GoogleSheetsHelper(this, "credentials.json");
        feePayments = new ArrayList<>();
        adapter = new FeePaymentAdapter(this, feePayments);
        rvFeeHistory.setLayoutManager(new LinearLayoutManager(this));
        rvFeeHistory.setAdapter(adapter);

        btnPayFee.setOnClickListener(v -> showPaymentDialog());
    }

    private void setupSpinners() {
        ArrayAdapter<String> semesterAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_item, SEMESTERS);
        semesterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSemester.setAdapter(semesterAdapter);

        ArrayAdapter<String> feeTypeAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_item, FEE_TYPES);
        feeTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFeeType.setAdapter(feeTypeAdapter);

        spinnerSemester.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadFeeStructure();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void loadStudentData(String studentId) {
        sheetsHelper.getStudents(new GoogleSheetsHelper.SheetsCallback() {
            @Override
            public void onResult(List<List<Object>> values) {
                if (values != null) {
                    for (List<Object> row : values) {
                        if (row.size() >= 9 && row.get(0).toString().equals(studentId)) {
                            student = new Student(
                                row.get(0).toString(),  // id
                                row.get(1).toString(),  // name
                                row.get(2).toString(),  // course
                                row.get(3).toString(),  // department
                                row.get(4).toString(),  // batch
                                row.get(5).toString(),  // gender
                                row.get(6).toString(),  // mobile
                                row.get(7).toString(),  // book
                                row.get(8).toString()   // photoUrl
                            );
                            runOnUiThread(() -> loadFeeStructure());
                            break;
                        }
                    }
                }
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(() -> Toast.makeText(FeeManagementActivity.this,
                    "Error loading student data", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void loadFeeStructure() {
        if (student == null) return;

        String semester = spinnerSemester.getSelectedItem().toString();
        sheetsHelper.getFeeStructure(student.getCourse(), semester,
            new GoogleSheetsCallback() {
                @Override
                public void onResult(List<List<Object>> values) {
                    if (values != null) {
                        for (List<Object> row : values) {
                            if (row.size() >= 6 &&
                                row.get(0).toString().equals(student.getCourse()) &&
                                row.get(5).toString().equals(semester)) {
                                feeStructure = new FeeStructure(
                                    row.get(0).toString(),  // courseId
                                    Double.parseDouble(row.get(1).toString()),  // tutionFee
                                    Double.parseDouble(row.get(2).toString()),  // examFee
                                    Double.parseDouble(row.get(3).toString()),  // otherFee
                                    Double.parseDouble(row.get(4).toString()),  // busFee
                                    row.get(5).toString()   // semester
                                );
                                runOnUiThread(() -> {
                                    updateFeeDisplay();
                                    loadFeePayments();
                                });
                                break;
                            }
                        }
                    }
                }

                @Override
                public void onError(Exception e) {
                    runOnUiThread(() -> Toast.makeText(FeeManagementActivity.this,
                        "Error loading fee structure", Toast.LENGTH_SHORT).show());
                }
            });
    }

    private void loadFeePayments() {
        if (student == null) return;

        String semester = spinnerSemester.getSelectedItem().toString();
        sheetsHelper.getFeePayments(student.getId(), semester,
            new GoogleSheetsCallback() {
                @Override
                public void onResult(List<List<Object>> values) {
                    feePayments.clear();
                    if (values != null) {
                        for (List<Object> row : values) {
                            if (row.size() >= 9 &&
                                row.get(0).toString().equals(student.getId()) &&
                                row.get(2).toString().equals(semester)) {
                                FeePayment payment = new FeePayment(
                                    row.get(0).toString(),  // studentId
                                    row.get(1).toString(),  // courseId
                                    row.get(2).toString(),  // semester
                                    row.get(3).toString(),  // feeType
                                    Double.parseDouble(row.get(4).toString()),  // amount
                                    row.get(5).toString(),  // paymentDate
                                    row.get(6).toString(),  // paymentMethod
                                    row.get(7).toString(),  // transactionId
                                    row.get(8).toString()   // status
                                );
                                feePayments.add(payment);
                            }
                        }
                    }
                    runOnUiThread(() -> {
                        adapter.notifyDataSetChanged();
                        updateFeeDisplay();
                    });
                }

                @Override
                public void onError(Exception e) {
                    runOnUiThread(() -> Toast.makeText(FeeManagementActivity.this,
                        "Error loading fee payments", Toast.LENGTH_SHORT).show());
                }
            });
    }

    private void updateFeeDisplay() {
        if (feeStructure == null) return;

        double totalFee = feeStructure.getTotalFee();
        double paidFee = calculatePaidFee();
        double dueFee = totalFee - paidFee;

        tvTotalFee.setText(String.format(Locale.getDefault(), "₹%.2f", totalFee));
        tvPaidFee.setText(String.format(Locale.getDefault(), "₹%.2f", paidFee));
        tvDueFee.setText(String.format(Locale.getDefault(), "₹%.2f", dueFee));
    }

    private double calculatePaidFee() {
        double total = 0;
        for (FeePayment payment : feePayments) {
            if (payment.getStatus().equals("Success")) {
                total += payment.getAmount();
            }
        }
        return total;
    }

    private void showPaymentDialog() {
        // Show payment dialog implementation
        // This would typically launch a payment gateway or show a dialog
        // for collecting payment details
    }
}
