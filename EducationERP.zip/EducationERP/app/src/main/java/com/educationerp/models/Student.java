package com.educationerp.models;

public class Student {
    private String id;
    private String name;
    private String course;
    private String department;
    private String batch;
    private String gender;
    private String mobile;
    private String book;
    private String photoUrl;

    public Student() {
        // Empty constructor required for Firebase
    }

    public Student(String id, String name, String course, String department, String batch,
                  String gender, String mobile, String book, String photoUrl) {
        this.id = id;
        this.name = name;
        this.course = course;
        this.department = department;
        this.batch = batch;
        this.gender = gender;
        this.mobile = mobile;
        this.book = book;
        this.photoUrl = photoUrl;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getBatch() { return batch; }
    public void setBatch(String batch) { this.batch = batch; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }

    public String getBook() { return book; }
    public void setBook(String book) { this.book = book; }

    public String getPhotoUrl() { return photoUrl; }
    public void setPhotoUrl(String photoUrl) { this.photoUrl = photoUrl; }
}
