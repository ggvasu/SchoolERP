package com.educationerp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.educationerp.R;
import java.util.List;
import java.util.Map;

public class RecentActivityAdapter extends RecyclerView.Adapter<RecentActivityAdapter.ViewHolder> {
    private List<Map<String, String>> activities;

    public RecentActivityAdapter(List<Map<String, String>> activities) {
        this.activities = activities;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_recent_activity, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Map<String, String> activity = activities.get(position);
        holder.tvActivityTitle.setText(activity.get("title"));
        holder.tvActivityDescription.setText(activity.get("description"));
        holder.tvActivityTime.setText(activity.get("time"));
    }

    @Override
    public int getItemCount() {
        return activities.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvActivityTitle;
        TextView tvActivityDescription;
        TextView tvActivityTime;

        ViewHolder(View view) {
            super(view);
            tvActivityTitle = view.findViewById(R.id.tvActivityTitle);
            tvActivityDescription = view.findViewById(R.id.tvActivityDescription);
            tvActivityTime = view.findViewById(R.id.tvActivityTime);
        }
    }
}
