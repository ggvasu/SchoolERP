package com.educationerp.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.educationerp.R;
import com.educationerp.models.Student;
import com.educationerp.utils.GoogleSheetsHelper;
import java.util.Arrays;
import java.util.UUID;
import java.util.List;


public class StudentManagementActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int PERMISSION_REQUEST_CODE = 200;
    
    private EditText etId, etName, etCourse, etDepartment, etBatch, etMobile, etBook;
    private RadioGroup rgGender;
    private ImageView ivPhoto;
    private Button btnSave, btnViewAll;
    private Uri selectedImageUri;
    private GoogleSheetsHelper sheetsHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_management);

        initializeViews();
        setupListeners();
        
        sheetsHelper = new GoogleSheetsHelper(this, "credentials.json");
    }

    private void initializeViews() {
        etId = findViewById(R.id.etId);
        etName = findViewById(R.id.etName);
        etCourse = findViewById(R.id.etCourse);
        etDepartment = findViewById(R.id.etDepartment);
        etBatch = findViewById(R.id.etBatch);
        etMobile = findViewById(R.id.etMobile);
        etBook = findViewById(R.id.etBook);
        rgGender = findViewById(R.id.rgGender);
        ivPhoto = findViewById(R.id.ivPhoto);
        btnSave = findViewById(R.id.btnSave);
        btnViewAll = findViewById(R.id.btnViewAll);
    }

    private void setupListeners() {
        ivPhoto.setOnClickListener(v -> checkPermissionAndPickImage());

        btnSave.setOnClickListener(v -> saveStudent());

        btnViewAll.setOnClickListener(v -> {
            Intent intent = new Intent(this, StudentListActivity.class);
            startActivity(intent);
        });
    }

    private void checkPermissionAndPickImage() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_CODE);
        } else {
            pickImage();
        }
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    private void saveStudent() {
        String id = etId.getText().toString();
        String name = etName.getText().toString();
        String course = etCourse.getText().toString();
        String department = etDepartment.getText().toString();
        String batch = etBatch.getText().toString();
        String gender = rgGender.getCheckedRadioButtonId() == R.id.rbMale ? "Male" : "Female";
        String mobile = etMobile.getText().toString();
        String book = etBook.getText().toString();
        String photoUrl = selectedImageUri != null ? selectedImageUri.toString() : "";

        if (validateInput(name, course, department, batch, mobile)) {
            Student student = new Student(id, name, course, department, batch, 
                                       gender, mobile, book, photoUrl);
            saveToGoogleSheets(student);
        }
    }

    private boolean validateInput(String... fields) {
        for (String field : fields) {
            if (field.isEmpty()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }

    private void saveToGoogleSheets(Student student) {
        List<Object> studentData = Arrays.asList(
            student.getId(), student.getName(), student.getCourse(),
            student.getDepartment(), student.getBatch(), student.getGender(),
            student.getMobile(), student.getBook(), student.getPhotoUrl()
        );

        sheetsHelper.addStudent(studentData, new GoogleSheetsHelper.SheetsCallback() {
            @Override
            public void onResult(List<List<Object>> values) {
                runOnUiThread(() -> {
                    Toast.makeText(StudentManagementActivity.this,
                        "Student saved successfully", Toast.LENGTH_SHORT).show();
                    clearFields();
                });
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(StudentManagementActivity.this,
                        "Error saving student: " + e.getMessage(),
                        Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void clearFields() {
        etId.setText("");
        etName.setText("");
        etCourse.setText("");
        etDepartment.setText("");
        etBatch.setText("");
        etMobile.setText("");
        etBook.setText("");
        ivPhoto.setImageResource(R.drawable.ic_photo_placeholder);
        selectedImageUri = null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            ivPhoto.setImageURI(selectedImageUri);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                         int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pickImage();
            }
        }
    }
}
