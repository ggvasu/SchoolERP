package com.educationerp.utils;

import android.content.Context;
import com.educationerp.models.FeePayment;
import com.educationerp.models.FeeReceipt;
import com.educationerp.models.FeeReport;
import com.educationerp.models.PaymentReminder;
import com.educationerp.models.Scholarship;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ReportGenerator {
    private Context context;
    private GoogleSheetsHelper sheetsHelper;
    private SimpleDateFormat dateFormat;

    public ReportGenerator(Context context) {
        this.context = context;
        this.sheetsHelper = new GoogleSheetsHelper(context, "credentials.json");
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    }

    public interface ReportCallback {
        void onReportGenerated(FeeReport report);
        void onError(Exception e);
    }

    public void generateReport(String startDate, String endDate, String reportType, 
                             final ReportCallback callback) {
        final FeeReport report = new FeeReport();
        report.setReportId(UUID.randomUUID().toString());
        report.setReportType(reportType);
        report.setStartDate(startDate);
        report.setEndDate(endDate);

        // Get all required data from sheets
        sheetsHelper.getFeePayments(new GoogleSheetsHelper.SheetsCallback() {
            @Override
            public void onResult(List<List<Object>> payments) {
                try {
                    processPayments(report, payments);
                    fetchScholarships(report, callback);
                } catch (Exception e) {
                    callback.onError(e);
                }
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    private void processPayments(FeeReport report, List<List<Object>> payments) 
            throws ParseException {
        double totalCollected = 0;
        Map<String, Double> feeTypeBreakdown = new HashMap<>();
        Map<String, Double> courseWiseCollection = new HashMap<>();
        Map<String, Double> semesterWiseCollection = new HashMap<>();
        List<FeePayment> recentPayments = new ArrayList<>();

        Date startDate = dateFormat.parse(report.getStartDate());
        Date endDate = dateFormat.parse(report.getEndDate());

        for (List<Object> row : payments) {
            if (row.size() < 9) continue;

            Date paymentDate = dateFormat.parse(row.get(5).toString());
            if (paymentDate.before(startDate) || paymentDate.after(endDate)) continue;

            double amount = Double.parseDouble(row.get(4).toString());
            String feeType = row.get(3).toString();
            String course = row.get(1).toString();
            String semester = row.get(2).toString();

            totalCollected += amount;

            // Update fee type breakdown
            feeTypeBreakdown.merge(feeType, amount, Double::sum);

            // Update course-wise collection
            courseWiseCollection.merge(course, amount, Double::sum);

            // Update semester-wise collection
            semesterWiseCollection.merge(semester, amount, Double::sum);

            // Add to recent payments
            FeePayment payment = new FeePayment();
            payment.setStudentId(row.get(0).toString());
            payment.setCourseId(course);
            payment.setSemester(semester);
            payment.setFeeType(feeType);
            payment.setAmount(amount);
            payment.setPaymentDate(row.get(5).toString());
            payment.setPaymentMethod(row.get(6).toString());
            payment.setTransactionId(row.get(7).toString());
            payment.setStatus(row.get(8).toString());
            recentPayments.add(payment);
        }

        report.setTotalCollectedAmount(totalCollected);
        report.setTotalTransactions(recentPayments.size());
        report.setFeeTypeBreakdown(feeTypeBreakdown);
        report.setCourseWiseCollection(courseWiseCollection);
        report.setSemesterWiseCollection(semesterWiseCollection);
        report.setRecentPayments(recentPayments);
    }

    private void fetchScholarships(final FeeReport report, final ReportCallback callback) {
        sheetsHelper.getScholarships(new GoogleSheetsHelper.SheetsCallback() {
            @Override
            public void onResult(List<List<Object>> scholarships) {
                try {
                    processScholarships(report, scholarships);
                    fetchReminders(report, callback);
                } catch (Exception e) {
                    callback.onError(e);
                }
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    private void processScholarships(FeeReport report, List<List<Object>> scholarships) {
        Map<String, Double> scholarshipUtilization = new HashMap<>();
        double totalDiscounts = 0;

        for (List<Object> row : scholarships) {
            if (row.size() < 8) continue;

            String name = row.get(1).toString();
            double amount = Double.parseDouble(row.get(3).toString());
            double percentageDiscount = Double.parseDouble(row.get(4).toString());
            boolean isActive = Boolean.parseBoolean(row.get(7).toString());

            if (isActive) {
                double utilization = amount + (percentageDiscount * report.getTotalCollectedAmount() / 100);
                scholarshipUtilization.put(name, utilization);
                totalDiscounts += utilization;
            }
        }

        report.setScholarshipUtilization(scholarshipUtilization);
        report.setTotalDiscountsGiven(totalDiscounts);
    }

    private void fetchReminders(final FeeReport report, final ReportCallback callback) {
        sheetsHelper.getPaymentReminders(null, new GoogleSheetsHelper.SheetsCallback() {
            @Override
            public void onResult(List<List<Object>> reminders) {
                try {
                    processReminders(report, reminders);
                    callback.onReportGenerated(report);
                } catch (Exception e) {
                    callback.onError(e);
                }
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
    }

    private void processReminders(FeeReport report, List<List<Object>> reminders) 
            throws ParseException {
        List<PaymentReminder> pendingReminders = new ArrayList<>();
        double totalPending = 0;
        Set<String> studentsWithDues = new HashSet<>();

        Date startDate = dateFormat.parse(report.getStartDate());
        Date endDate = dateFormat.parse(report.getEndDate());

        for (List<Object> row : reminders) {
            if (row.size() < 10) continue;

            Date dueDate = dateFormat.parse(row.get(3).toString());
            if (dueDate.before(startDate) || dueDate.after(endDate)) continue;

            String status = row.get(6).toString();
            if (status.equals("Pending")) {
                PaymentReminder reminder = new PaymentReminder();
                reminder.setId(row.get(0).toString());
                reminder.setStudentId(row.get(1).toString());
                reminder.setSemester(row.get(2).toString());
                reminder.setDueDate(row.get(3).toString());
                reminder.setDueAmount(Double.parseDouble(row.get(4).toString()));
                reminder.setReminderType(row.get(5).toString());
                reminder.setStatus(status);
                reminder.setMessage(row.get(7).toString());
                reminder.setCreatedDate(row.get(8).toString());
                reminder.setSentDate(row.get(9).toString());

                pendingReminders.add(reminder);
                totalPending += reminder.getDueAmount();
                studentsWithDues.add(reminder.getStudentId());
            }
        }

        report.setPendingReminders(pendingReminders);
        report.setTotalPendingAmount(totalPending);
        report.setTotalStudentsWithDues(studentsWithDues.size());
    }
}
