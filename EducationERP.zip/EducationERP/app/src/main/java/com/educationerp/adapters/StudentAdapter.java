package com.educationerp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.educationerp.R;
import com.educationerp.models.Student;
import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.StudentViewHolder> {
    private Context context;
    private List<Student> studentList;
    private OnStudentClickListener listener;

    public interface OnStudentClickListener {
        void onStudentClick(Student student);
    }

    public StudentAdapter(Context context, List<Student> studentList, OnStudentClickListener listener) {
        this.context = context;
        this.studentList = studentList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_student, parent, false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        Student student = studentList.get(position);
        holder.bind(student);
    }

    @Override
    public int getItemCount() {
        return studentList.size();
    }

    public void updateList(List<Student> newList) {
        studentList = newList;
        notifyDataSetChanged();
    }

    class StudentViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivStudentPhoto;
        private TextView tvStudentName;
        private TextView tvStudentId;
        private TextView tvCourse;
        private TextView tvDepartment;

        StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            ivStudentPhoto = itemView.findViewById(R.id.ivStudentPhoto);
            tvStudentName = itemView.findViewById(R.id.tvStudentName);
            tvStudentId = itemView.findViewById(R.id.tvStudentId);
            tvCourse = itemView.findViewById(R.id.tvCourse);
            tvDepartment = itemView.findViewById(R.id.tvDepartment);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onStudentClick(studentList.get(position));
                }
            });
        }

        void bind(Student student) {
            tvStudentName.setText(student.getName());
            tvStudentId.setText(student.getId());
            tvCourse.setText(student.getCourse());
            tvDepartment.setText(student.getDepartment());

            if (!student.getPhotoUrl().isEmpty()) {
                Glide.with(context)
                    .load(student.getPhotoUrl())
                    .placeholder(R.drawable.ic_photo_placeholder)
                    .error(R.drawable.ic_photo_placeholder)
                    .circleCrop()
                    .into(ivStudentPhoto);
            } else {
                ivStudentPhoto.setImageResource(R.drawable.ic_photo_placeholder);
            }
        }
    }
}
