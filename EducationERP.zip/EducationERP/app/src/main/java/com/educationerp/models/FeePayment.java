package com.educationerp.models;

import java.util.Date;

public class FeePayment {
    private String studentId;
    private String courseId;
    private String semester;
    private String feeType;
    private double amount;
    private String paymentDate;
    private String paymentMethod;
    private String transactionId;
    private String status;

    public FeePayment() {
        // Empty constructor required for Firebase
    }

    public FeePayment(String studentId, String courseId, String semester, String feeType,
                     double amount, String paymentDate, String paymentMethod,
                     String transactionId, String status) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.semester = semester;
        this.feeType = feeType;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
        this.transactionId = transactionId;
        this.status = status;
    }

    // Getters and Setters
    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getFeeType() { return feeType; }
    public void setFeeType(String feeType) { this.feeType = feeType; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getPaymentDate() { return paymentDate; }
    public void setPaymentDate(String paymentDate) { this.paymentDate = paymentDate; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
