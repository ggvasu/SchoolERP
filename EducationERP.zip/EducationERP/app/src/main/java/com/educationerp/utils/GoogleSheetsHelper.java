package com.educationerp.utils;

import android.content.Context;
import android.os.AsyncTask;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.ValueRange;
import java.util.Arrays;
import java.util.List;



public class GoogleSheetsHelper {
    private static final String SPREADSHEET_ID = "15fCwztdD-W13RG0jiyD2D-Mku56hFywS0uaGXgiD1zg";
    private static final String STUDENTS_RANGE = "Students!A:I";
    private static final String ATTENDANCE_RANGE = "Attendance!A:D";
    private static final String FEE_STRUCTURE_RANGE = "FeeStructure!A:F";
    private static final String FEE_PAYMENTS_RANGE = "FeePayments!A:I";
    private static final String SCHOLARSHIPS_RANGE = "Scholarships!A:H";
    private static final String FEE_RECEIPTS_RANGE = "FeeReceipts!A:N";
    private static final String PAYMENT_REMINDERS_RANGE = "PaymentReminders!A:J";
    private Sheets sheetsService;

    public interface SheetsCallback {
        void onResult(List<List<Object>> values);
        void onError(Exception e);

    }

    public GoogleSheetsHelper(Context context, String credentialsJson) {
        try {
            GoogleCredential credential = GoogleCredential.fromStream(
                context.getAssets().open(credentialsJson))
                .createScoped(Arrays.asList(
                    "https://www.googleapis.com/auth/spreadsheets"));

            sheetsService = new Sheets.Builder(
                new NetHttpTransport(),
                JacksonFactory.getDefaultInstance(),
                credential)
                .setApplicationName("Education ERP")
                .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getStudents(final SheetsCallback callback) {
        new AsyncTask<Void, Void, List<List<Object>>>() {
            private Exception error;

            @Override
            protected List<List<Object>> doInBackground(Void... voids) {
                try {
                    ValueRange response = sheetsService.spreadsheets().values()
                        .get(SPREADSHEET_ID, STUDENTS_RANGE)
                        .execute();
                    return response.getValues();
                } catch (Exception e) {
                    error = e;
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<List<Object>> values) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(values);
                }
            }
        }.execute();
    }

    public void addStudent(final List<Object> studentData, final SheetsCallback callback) {
        new AsyncTask<Void, Void, Void>() {
            private Exception error;

            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    ValueRange body = new ValueRange()
                        .setValues(Arrays.asList(studentData));
                    sheetsService.spreadsheets().values()
                        .append(SPREADSHEET_ID, STUDENTS_RANGE, body)
                        .setValueInputOption("RAW")
                        .execute();
                } catch (Exception e) {
                    error = e;
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(null);
                }
            }
        }.execute();
    }

    public void getFeeStructure(final String courseId, final String semester, final SheetsCallback callback) {
        new AsyncTask<Void, Void, List<List<Object>>>() {
            private Exception error;

            @Override
            protected List<List<Object>> doInBackground(Void... voids) {
                try {
                    ValueRange response = sheetsService.spreadsheets().values()
                        .get(SPREADSHEET_ID, FEE_STRUCTURE_RANGE)
                        .execute();
                    return response.getValues();
                } catch (Exception e) {
                    error = e;
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<List<Object>> values) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(values);
                }
            }
        }.execute();
    }

    public void addFeeStructure(final List<Object> feeStructureData, final SheetsCallback callback) {
        new AsyncTask<Void, Void, Void>() {
            private Exception error;

            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    ValueRange body = new ValueRange()
                        .setValues(Arrays.asList(feeStructureData));
                    sheetsService.spreadsheets().values()
                        .append(SPREADSHEET_ID, FEE_STRUCTURE_RANGE, body)
                        .setValueInputOption("RAW")
                        .execute();
                } catch (Exception e) {
                    error = e;
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(null);
                }
            }
        }.execute();
    }

    public void getFeePayments(final String studentId, final String semester, final SheetsCallback callback) {
        new AsyncTask<Void, Void, List<List<Object>>>() {
            private Exception error;

            @Override
            protected List<List<Object>> doInBackground(Void... voids) {
                try {
                    ValueRange response = sheetsService.spreadsheets().values()
                        .get(SPREADSHEET_ID, FEE_PAYMENTS_RANGE)
                        .execute();
                    return response.getValues();
                } catch (Exception e) {
                    error = e;
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<List<Object>> values) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(values);
                }
            }
        }.execute();
    }

    public void addFeePayment(final List<Object> feePaymentData, final SheetsCallback callback) {
        new AsyncTask<Void, Void, Void>() {
            private Exception error;

            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    ValueRange body = new ValueRange()
                        .setValues(Arrays.asList(feePaymentData));
                    sheetsService.spreadsheets().values()
                        .append(SPREADSHEET_ID, FEE_PAYMENTS_RANGE, body)
                        .setValueInputOption("RAW")
                        .execute();
                } catch (Exception e) {
                    error = e;
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(null);
                }
            }
        }.execute();
    }

    public void getAttendance(String studentId, final SheetsCallback callback) {
        new AsyncTask<Void, Void, List<List<Object>>>() {
            private Exception error;

            @Override
            protected List<List<Object>> doInBackground(Void... voids) {
                try {
                    ValueRange response = sheetsService.spreadsheets().values()
                        .get(SPREADSHEET_ID, ATTENDANCE_RANGE)
                        .execute();
                    return response.getValues();
                } catch (Exception e) {
                    error = e;
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<List<Object>> values) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(values);
                }
            }
        }.execute();
    }

    public void markAttendance(final List<Object> attendanceData, final SheetsCallback callback) {
        new AsyncTask<Void, Void, Void>() {
            private Exception error;

            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    ValueRange body = new ValueRange()
                        .setValues(Arrays.asList(attendanceData));
                    sheetsService.spreadsheets().values()
                        .append(SPREADSHEET_ID, ATTENDANCE_RANGE, body)
                        .setValueInputOption("RAW")
                        .execute();
                } catch (Exception e) {
                    error = e;
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(null);
                }
            }
        }.execute();
    }

    public void getScholarships(final SheetsCallback callback) {
        new AsyncTask<Void, Void, List<List<Object>>>() {
            private Exception error;

            @Override
            protected List<List<Object>> doInBackground(Void... voids) {
                try {
                    ValueRange response = sheetsService.spreadsheets().values()
                        .get(SPREADSHEET_ID, SCHOLARSHIPS_RANGE)
                        .execute();
                    return response.getValues();
                } catch (Exception e) {
                    error = e;
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<List<Object>> values) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(values);
                }
            }
        }.execute();
    }

    public void addScholarship(final List<Object> scholarshipData, final SheetsCallback callback) {
        new AsyncTask<Void, Void, Void>() {
            private Exception error;

            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    ValueRange body = new ValueRange()
                        .setValues(Arrays.asList(scholarshipData));
                    sheetsService.spreadsheets().values()
                        .append(SPREADSHEET_ID, SCHOLARSHIPS_RANGE, body)
                        .setValueInputOption("RAW")
                        .execute();
                } catch (Exception e) {
                    error = e;
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(null);
                }
            }
        }.execute();
    }

    public void getFeeReceipts(final String studentId, final SheetsCallback callback) {
        new AsyncTask<Void, Void, List<List<Object>>>() {
            private Exception error;

            @Override
            protected List<List<Object>> doInBackground(Void... voids) {
                try {
                    ValueRange response = sheetsService.spreadsheets().values()
                        .get(SPREADSHEET_ID, FEE_RECEIPTS_RANGE)
                        .execute();
                    return response.getValues();
                } catch (Exception e) {
                    error = e;
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<List<Object>> values) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(values);
                }
            }
        }.execute();
    }

    public void addFeeReceipt(final List<Object> receiptData, final SheetsCallback callback) {
        new AsyncTask<Void, Void, Void>() {
            private Exception error;

            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    ValueRange body = new ValueRange()
                        .setValues(Arrays.asList(receiptData));
                    sheetsService.spreadsheets().values()
                        .append(SPREADSHEET_ID, FEE_RECEIPTS_RANGE, body)
                        .setValueInputOption("RAW")
                        .execute();
                } catch (Exception e) {
                    error = e;
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(null);
                }
            }
        }.execute();
    }

    public void getPaymentReminders(final String studentId, final SheetsCallback callback) {
        new AsyncTask<Void, Void, List<List<Object>>>() {
            private Exception error;

            @Override
            protected List<List<Object>> doInBackground(Void... voids) {
                try {
                    ValueRange response = sheetsService.spreadsheets().values()
                        .get(SPREADSHEET_ID, PAYMENT_REMINDERS_RANGE)
                        .execute();
                    return response.getValues();
                } catch (Exception e) {
                    error = e;
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<List<Object>> values) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(values);
                }
            }
        }.execute();
    }

    public void addPaymentReminder(final List<Object> reminderData, final SheetsCallback callback) {
        new AsyncTask<Void, Void, Void>() {
            private Exception error;

            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    ValueRange body = new ValueRange()
                        .setValues(Arrays.asList(reminderData));
                    sheetsService.spreadsheets().values()
                        .append(SPREADSHEET_ID, PAYMENT_REMINDERS_RANGE, body)
                        .setValueInputOption("RAW")
                        .execute();
                } catch (Exception e) {
                    error = e;
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                if (error != null) {
                    callback.onError(error);
                } else {
                    callback.onResult(null);
                }
            }
        }.execute();
    }
}
