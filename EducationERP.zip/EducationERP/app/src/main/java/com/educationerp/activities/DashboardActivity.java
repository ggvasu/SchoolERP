package com.educationerp.activities;

import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.educationerp.R;
import com.educationerp.adapters.RecentActivityAdapter;
import com.educationerp.models.Student;
import com.educationerp.utils.GoogleSheetsHelper;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import java.util.*;

public class DashboardActivity extends AppCompatActivity {
    private GoogleSheetsHelper sheetsHelper;
    private TextView tvTotalStudents, tvMaleCount, tvFemaleCount, tvTotalFeeCollection;
    private PieChart chartCourses;
    private LineChart chartTrends;
    private CircularProgressIndicator progressAttendance;
    private RecyclerView rvRecentActivities;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        initializeViews();
        setupToolbar();
        setupCharts();
        loadDashboardData();
    }

    private void initializeViews() {
        tvTotalStudents = findViewById(R.id.tvTotalStudents);
        tvMaleCount = findViewById(R.id.tvMaleCount);
        tvFemaleCount = findViewById(R.id.tvFemaleCount);
        tvTotalFeeCollection = findViewById(R.id.tvTotalFeeCollection);
        chartCourses = findViewById(R.id.chartCourses);
        chartTrends = findViewById(R.id.chartTrends);
        progressAttendance = findViewById(R.id.progressAttendance);
        rvRecentActivities = findViewById(R.id.rvRecentActivities);

        sheetsHelper = new GoogleSheetsHelper(this, "credentials.json");
        rvRecentActivities.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Dashboard");
    }

    private void setupCharts() {
        // Setup Course Distribution Chart
        chartCourses.getDescription().setEnabled(false);
        chartCourses.setDrawHoleEnabled(true);
        chartCourses.setHoleColor(Color.WHITE);
        chartCourses.setTransparentCircleRadius(30f);
        chartCourses.setDrawEntryLabels(false);
        chartCourses.getLegend().setEnabled(false);

        // Setup Enrollment Trends Chart
        chartTrends.getDescription().setEnabled(false);
        chartTrends.setDrawGridBackground(false);
        chartTrends.setDrawBorders(false);
        chartTrends.getAxisRight().setEnabled(false);
        chartTrends.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        chartTrends.getXAxis().setGranularity(1f);
        chartTrends.animateY(1000);
    }

    private void loadDashboardData() {
        sheetsHelper.getStudents(new GoogleSheetsHelper.SheetsCallback() {
            @Override
            public void onResult(List<List<Object>> values) {
                if (values != null) {
                    processStudentData(values);
                }
            }

            @Override
            public void onError(Exception e) {
                // Handle error
            }
        });

        loadFeeData();
        loadAttendanceData();
        loadRecentActivities();
    }

    private void processStudentData(List<List<Object>> values) {
        int totalStudents = values.size() - 1; // Excluding header row
        int maleCount = 0;
        int femaleCount = 0;
        Map<String, Integer> courseDistribution = new HashMap<>();

        for (int i = 1; i < values.size(); i++) {
            List<Object> row = values.get(i);
            if (row.size() >= 6) {
                String gender = row.get(5).toString();
                String course = row.get(2).toString();

                if (gender.equalsIgnoreCase("Male")) {
                    maleCount++;
                } else if (gender.equalsIgnoreCase("Female")) {
                    femaleCount++;
                }

                courseDistribution.merge(course, 1, Integer::sum);
            }
        }

        updateStudentStats(totalStudents, maleCount, femaleCount);
        updateCourseDistributionChart(courseDistribution);
        updateEnrollmentTrendsChart(values);
    }

    private void updateStudentStats(int total, int male, int female) {
        runOnUiThread(() -> {
            tvTotalStudents.setText(String.valueOf(total));
            tvMaleCount.setText(String.format("M: %d", male));
            tvFemaleCount.setText(String.format("F: %d", female));
        });
    }

    private void updateCourseDistributionChart(Map<String, Integer> distribution) {
        List<PieEntry> entries = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : distribution.entrySet()) {
            entries.add(new PieEntry(entry.getValue(), entry.getKey()));
        }

        PieDataSet dataSet = new PieDataSet(entries, "Courses");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.WHITE);

        PieData data = new PieData(dataSet);
        runOnUiThread(() -> chartCourses.setData(data));
    }

    private void updateEnrollmentTrendsChart(List<List<Object>> values) {
        // Group students by batch/year
        Map<String, Integer> batchDistribution = new TreeMap<>();
        for (int i = 1; i < values.size(); i++) {
            List<Object> row = values.get(i);
            if (row.size() >= 5) {
                String batch = row.get(4).toString();
                batchDistribution.merge(batch, 1, Integer::sum);
            }
        }

        List<Entry> entries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int index = 0;
        for (Map.Entry<String, Integer> entry : batchDistribution.entrySet()) {
            entries.add(new Entry(index, entry.getValue()));
            labels.add(entry.getKey());
            index++;
        }

        LineDataSet dataSet = new LineDataSet(entries, "Students");
        dataSet.setColor(getResources().getColor(R.color.purple_500));
        dataSet.setLineWidth(2f);
        dataSet.setCircleColor(getResources().getColor(R.color.purple_500));
        dataSet.setCircleRadius(4f);
        dataSet.setDrawValues(true);
        dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);

        LineData lineData = new LineData(dataSet);
        XAxis xAxis = chartTrends.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));

        runOnUiThread(() -> chartTrends.setData(lineData));
    }

    private void loadFeeData() {
        sheetsHelper.getFeePayments(new GoogleSheetsHelper.SheetsCallback() {
            @Override
            public void onResult(List<List<Object>> values) {
                if (values != null) {
                    double totalCollection = 0;
                    for (int i = 1; i < values.size(); i++) {
                        List<Object> row = values.get(i);
                        if (row.size() >= 5) {
                            totalCollection += Double.parseDouble(row.get(4).toString());
                        }
                    }
                    final double finalTotal = totalCollection;
                    runOnUiThread(() -> tvTotalFeeCollection.setText(
                        String.format("₹%.2f", finalTotal)));
                }
            }

            @Override
            public void onError(Exception e) {
                // Handle error
            }
        });
    }

    private void loadAttendanceData() {
        sheetsHelper.getAttendance(new GoogleSheetsHelper.SheetsCallback() {
            @Override
            public void onResult(List<List<Object>> values) {
                if (values != null) {
                    int present = 0;
                    int total = 0;
                    for (int i = 1; i < values.size(); i++) {
                        List<Object> row = values.get(i);
                        if (row.size() >= 4) {
                            total++;
                            if (row.get(3).toString().equalsIgnoreCase("Present")) {
                                present++;
                            }
                        }
                    }
                    final int attendance = total > 0 ? (present * 100) / total : 0;
                    runOnUiThread(() -> progressAttendance.setProgress(attendance));
                }
            }

            @Override
            public void onError(Exception e) {
                // Handle error
            }
        });
    }

    private void loadRecentActivities() {
        // Combine recent fee payments and attendance records
        List<Map<String, String>> activities = new ArrayList<>();
        // Add activities from different sources
        // Sort by date
        // Show in RecyclerView
        RecentActivityAdapter adapter = new RecentActivityAdapter(activities);
        runOnUiThread(() -> rvRecentActivities.setAdapter(adapter));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
