package com.educationerp.models;

import java.util.List;

public class FeeReceipt {
    private String receiptNumber;
    private String studentId;
    private String studentName;
    private String course;
    private String semester;
    private String paymentDate;
    private List<FeePayment> payments;
    private List<Scholarship> appliedScholarships;
    private double totalAmount;
    private double discountAmount;
    private double netAmount;
    private String paymentMethod;
    private String transactionId;
    private String status;

    public FeeReceipt() {
        // Empty constructor required for Firebase
    }

    public FeeReceipt(String receiptNumber, String studentId, String studentName,
                      String course, String semester, String paymentDate,
                      List<FeePayment> payments, List<Scholarship> appliedScholarships,
                      double totalAmount, double discountAmount, double netAmount,
                      String paymentMethod, String transactionId, String status) {
        this.receiptNumber = receiptNumber;
        this.studentId = studentId;
        this.studentName = studentName;
        this.course = course;
        this.semester = semester;
        this.paymentDate = paymentDate;
        this.payments = payments;
        this.appliedScholarships = appliedScholarships;
        this.totalAmount = totalAmount;
        this.discountAmount = discountAmount;
        this.netAmount = netAmount;
        this.paymentMethod = paymentMethod;
        this.transactionId = transactionId;
        this.status = status;
    }

    // Getters and Setters
    public String getReceiptNumber() { return receiptNumber; }
    public void setReceiptNumber(String receiptNumber) { 
        this.receiptNumber = receiptNumber; 
    }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getPaymentDate() { return paymentDate; }
    public void setPaymentDate(String paymentDate) { this.paymentDate = paymentDate; }

    public List<FeePayment> getPayments() { return payments; }
    public void setPayments(List<FeePayment> payments) { this.payments = payments; }

    public List<Scholarship> getAppliedScholarships() { return appliedScholarships; }
    public void setAppliedScholarships(List<Scholarship> appliedScholarships) { 
        this.appliedScholarships = appliedScholarships; 
    }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    public double getDiscountAmount() { return discountAmount; }
    public void setDiscountAmount(double discountAmount) { 
        this.discountAmount = discountAmount; 
    }

    public double getNetAmount() { return netAmount; }
    public void setNetAmount(double netAmount) { this.netAmount = netAmount; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { 
        this.paymentMethod = paymentMethod; 
    }

    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { 
        this.transactionId = transactionId; 
    }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public void calculateNetAmount() {
        double totalDiscount = 0;
        for (Scholarship scholarship : appliedScholarships) {
            totalDiscount += scholarship.calculateDiscount(totalAmount);
        }
        this.discountAmount = totalDiscount;
        this.netAmount = totalAmount - discountAmount;
    }
}
