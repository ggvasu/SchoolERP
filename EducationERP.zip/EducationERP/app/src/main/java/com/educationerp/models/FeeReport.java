package com.educationerp.models;

import java.util.List;
import java.util.Map;

public class FeeReport {
    private String reportId;
    private String reportType; // Daily, Monthly, Semester, Annual
    private String startDate;
    private String endDate;
    private double totalCollectedAmount;
    private double totalPendingAmount;
    private int totalTransactions;
    private Map<String, Double> feeTypeBreakdown; // Type -> Amount
    private Map<String, Double> courseWiseCollection; // Course -> Amount
    private Map<String, Double> semesterWiseCollection; // Semester -> Amount
    private List<FeePayment> recentPayments;
    private List<PaymentReminder> pendingReminders;
    private Map<String, Double> scholarshipUtilization; // Scholarship -> Amount
    private double totalDiscountsGiven;
    private int totalStudentsWithDues;

    public FeeReport() {
        // Empty constructor
    }

    // Getters and Setters
    public String getReportId() { return reportId; }
    public void setReportId(String reportId) { this.reportId = reportId; }

    public String getReportType() { return reportType; }
    public void setReportType(String reportType) { this.reportType = reportType; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public double getTotalCollectedAmount() { return totalCollectedAmount; }
    public void setTotalCollectedAmount(double totalCollectedAmount) { 
        this.totalCollectedAmount = totalCollectedAmount; 
    }

    public double getTotalPendingAmount() { return totalPendingAmount; }
    public void setTotalPendingAmount(double totalPendingAmount) { 
        this.totalPendingAmount = totalPendingAmount; 
    }

    public int getTotalTransactions() { return totalTransactions; }
    public void setTotalTransactions(int totalTransactions) { 
        this.totalTransactions = totalTransactions; 
    }

    public Map<String, Double> getFeeTypeBreakdown() { return feeTypeBreakdown; }
    public void setFeeTypeBreakdown(Map<String, Double> feeTypeBreakdown) { 
        this.feeTypeBreakdown = feeTypeBreakdown; 
    }

    public Map<String, Double> getCourseWiseCollection() { return courseWiseCollection; }
    public void setCourseWiseCollection(Map<String, Double> courseWiseCollection) { 
        this.courseWiseCollection = courseWiseCollection; 
    }

    public Map<String, Double> getSemesterWiseCollection() { return semesterWiseCollection; }
    public void setSemesterWiseCollection(Map<String, Double> semesterWiseCollection) { 
        this.semesterWiseCollection = semesterWiseCollection; 
    }

    public List<FeePayment> getRecentPayments() { return recentPayments; }
    public void setRecentPayments(List<FeePayment> recentPayments) { 
        this.recentPayments = recentPayments; 
    }

    public List<PaymentReminder> getPendingReminders() { return pendingReminders; }
    public void setPendingReminders(List<PaymentReminder> pendingReminders) { 
        this.pendingReminders = pendingReminders; 
    }

    public Map<String, Double> getScholarshipUtilization() { return scholarshipUtilization; }
    public void setScholarshipUtilization(Map<String, Double> scholarshipUtilization) { 
        this.scholarshipUtilization = scholarshipUtilization; 
    }

    public double getTotalDiscountsGiven() { return totalDiscountsGiven; }
    public void setTotalDiscountsGiven(double totalDiscountsGiven) { 
        this.totalDiscountsGiven = totalDiscountsGiven; 
    }

    public int getTotalStudentsWithDues() { return totalStudentsWithDues; }
    public void setTotalStudentsWithDues(int totalStudentsWithDues) { 
        this.totalStudentsWithDues = totalStudentsWithDues; 
    }

    // Helper methods for report generation
    public double getCollectionEfficiency() {
        double totalAmount = totalCollectedAmount + totalPendingAmount;
        return totalAmount > 0 ? (totalCollectedAmount / totalAmount) * 100 : 0;
    }

    public double getAverageTransactionAmount() {
        return totalTransactions > 0 ? totalCollectedAmount / totalTransactions : 0;
    }

    public String generateSummary() {
        return String.format(
            "Fee Collection Report (%s to %s)\n\n" +
            "Total Collection: ₹%.2f\n" +
            "Pending Amount: ₹%.2f\n" +
            "Collection Efficiency: %.1f%%\n" +
            "Total Transactions: %d\n" +
            "Average Transaction: ₹%.2f\n" +
            "Total Discounts: ₹%.2f\n" +
            "Students with Dues: %d",
            startDate, endDate, totalCollectedAmount, totalPendingAmount,
            getCollectionEfficiency(), totalTransactions, getAverageTransactionAmount(),
            totalDiscountsGiven, totalStudentsWithDues
        );
    }
}
