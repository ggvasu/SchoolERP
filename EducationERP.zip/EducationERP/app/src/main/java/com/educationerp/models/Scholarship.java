package com.educationerp.models;

public class Scholarship {
    private String id;
    private String name;
    private String type; // Merit, Income-based, Sports, etc.
    private double amount;
    private double percentageDiscount;
    private String criteria;
    private String validityPeriod;
    private boolean isActive;

    public Scholarship() {
        // Empty constructor required for Firebase
    }

    public Scholarship(String id, String name, String type, double amount,
                      double percentageDiscount, String criteria,
                      String validityPeriod, boolean isActive) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.amount = amount;
        this.percentageDiscount = percentageDiscount;
        this.criteria = criteria;
        this.validityPeriod = validityPeriod;
        this.isActive = isActive;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public double getPercentageDiscount() { return percentageDiscount; }
    public void setPercentageDiscount(double percentageDiscount) { 
        this.percentageDiscount = percentageDiscount; 
    }

    public String getCriteria() { return criteria; }
    public void setCriteria(String criteria) { this.criteria = criteria; }

    public String getValidityPeriod() { return validityPeriod; }
    public void setValidityPeriod(String validityPeriod) { 
        this.validityPeriod = validityPeriod; 
    }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public double calculateDiscount(double originalAmount) {
        if (percentageDiscount > 0) {
            return (originalAmount * percentageDiscount) / 100;
        }
        return amount;
    }
}
